# README
Run [Main.sh] file to process all splited miRNA file under [splited miRNA]. Be sure to have RNA Distance command-line tool preinstalled. 

Result is shown in [RNADistance_By_Motif]
