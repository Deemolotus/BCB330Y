# README
[File Conversation.rmd] is used exclusively for data conversion of primary vcf, bed and fasta file, which stores mutation, gene location and gene sequence information.  

[File Validation.rmd] is used to varify data primary in between vcf file and bed file, to check to see if mutation can be correstly applied. 