# READ ME
This folder consist of gene expression analysis using R package deseq2, see below for guidance https://bioc.ism.ac.jp/packages/2.14/bioc/vignettes/DESeq2/inst/doc/beginner.pdf

Folder [Breast Cancer Analysis] is consisted with gene expression analysis, data from fireBrowser, located: [FireBrowse](http://firebrowse.org/)

Folder [miRNA GENEXP-MUT Analysis] is consisted with gene expression analysis with crossed data from ICGC, see the work flow section from the report for more info. 
